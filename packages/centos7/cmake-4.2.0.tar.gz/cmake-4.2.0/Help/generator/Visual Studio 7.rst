Visual Studio 7
---------------

Removed.  This once generated Visual Studio .NET 2002 project files, but
the generator has been removed since CMake 3.6.  It is still possible to
build with VS 7.0 tools using the :generator:`NMake Makefiles` generator.
