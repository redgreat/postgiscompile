#pragma once

// TODO10: Include <OpAdd.h>, <OpMul.h>, and <OpSub.h>

namespace mathfunctions {
double sqrt(double x);
}
