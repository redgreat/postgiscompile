namespace mathfunctions {
double OpAdd(double a, double b)
{
  return a + b;
}
}
