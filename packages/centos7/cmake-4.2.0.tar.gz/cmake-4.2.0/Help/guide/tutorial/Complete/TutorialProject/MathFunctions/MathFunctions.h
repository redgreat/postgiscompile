#pragma once

#include <OpAdd.h>
#include <OpMul.h>
#include <OpSub.h>

namespace mathfunctions {
double sqrt(double x);
}
