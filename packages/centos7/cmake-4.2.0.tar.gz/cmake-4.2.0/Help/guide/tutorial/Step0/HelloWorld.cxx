#include <cstdio>

int main()
{
  std::printf("Hello World\n");
}
