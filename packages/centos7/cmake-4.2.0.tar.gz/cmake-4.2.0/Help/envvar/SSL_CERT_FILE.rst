SSL_CERT_FILE
-------------

.. versionadded:: 3.25

.. include:: include/ENV_VAR.rst

Specify the file name containing CA certificates.  It overrides the
default, os-specific CA file used.
