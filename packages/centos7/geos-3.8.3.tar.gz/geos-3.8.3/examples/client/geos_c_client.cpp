#include <geos_c.h>

int main()
{
    finishGEOS();
}