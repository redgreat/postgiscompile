CREATE EXTENSION pg_wait_sampling;

\d pg_wait_sampling_current
\d pg_wait_sampling_history
\d pg_wait_sampling_profile

DROP EXTENSION pg_wait_sampling;
