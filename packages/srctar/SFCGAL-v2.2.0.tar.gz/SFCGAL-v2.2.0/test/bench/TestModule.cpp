// Copyright (c) 2012-2013, IGN France.
// Copyright (c) 2012-2024, Oslandia.
// Copyright (c) 2024-2025, SFCGAL team.
// SPDX-License-Identifier: LGPL-2.0-or-later

#define BOOST_TEST_MODULE BenchTestSFCGAL

#include <boost/test/unit_test.hpp>
using namespace boost::unit_test;
