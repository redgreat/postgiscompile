## Description

XXX

## CI GitHub Status

- MSYS2: [![MSYS2](https://github.com/Oslandia/SFCGAL_CI/actions/workflows/msys.yml/badge.svg?branch=%{source_branch})](https://github.com/Oslandia/SFCGAL_CI/actions/workflows/msys.yml)
- VCPKG: [![Build with vcpkg](https://github.com/Oslandia/SFCGAL_CI/actions/workflows/vcpkg.yml/badge.svg?branch=%{source_branch})](https://github.com/Oslandia/SFCGAL_CI/actions/workflows/vcpkg.yml)
- BSD: [![CI](https://github.com/Oslandia/SFCGAL_CI/actions/workflows/ci.yml/badge.svg?branch=%{source_branch})](https://github.com/Oslandia/SFCGAL_CI/actions/workflows/ci.yml)

## Tests

- [ ] Unit
- [ ] C api
