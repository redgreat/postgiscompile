# Authors

Development of SFCGAL is led by [Oslandia](https://oslandia.com).

## Initial Authors

- Mickael Borne / IGN
- Hugo Mercier / Oslandia
- Vincent Mora / Oslandia
- Olivier Courtin / Oslandia

## All Authors

{{ include_file("../AUTHORS") }}
