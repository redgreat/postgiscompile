# Percona Code of Conduct

All Percona Products follow the [Percona Community Code of Conduct](https://github.com/percona/community/blob/main/content/contribute/coc.md).

If you notice any unacceptable behavior, let us know as soon as possible by writing to <community-team@percona.com>. We will respond within 48 hours.
