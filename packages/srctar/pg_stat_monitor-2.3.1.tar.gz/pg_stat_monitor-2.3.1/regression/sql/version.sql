CREATE EXTENSION pg_stat_monitor;
SELECT pg_stat_monitor_version();
DROP EXTENSION pg_stat_monitor;
