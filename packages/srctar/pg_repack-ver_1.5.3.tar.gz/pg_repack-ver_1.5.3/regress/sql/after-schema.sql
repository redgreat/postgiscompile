--
-- tables schema after running repack
--

\d tbl_cluster
\d tbl_gistkey
\d tbl_only_ckey
\d tbl_only_pkey
\d tbl_incl_pkey
\d tbl_with_dropped_column
\d tbl_with_dropped_toast
\d tbl_idxopts
