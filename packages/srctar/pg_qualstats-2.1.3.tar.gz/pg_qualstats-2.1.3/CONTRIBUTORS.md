  * Ronan Dunklau
  * Vik Fearing
  * Thomas Reiss
  * Julien Rouhaud
  * shribe
  * Tomas Vondra
  * Stéphane Tachoires
  * Pavel Trukhanov
  * Andreas Seltenreich
  * Nicolas Gollet
  * Gürkan Gür
  * Devrim Gündüz
  * github user seqizz
  * github user akovac
  * Romain DEP
  * github user suprimex
  * github user RekGRpth
  * Zhihong Yu
  * github user romanstingler
  * Kenny Chen
