  * Thomas Reiss
  * Julien Rouhaud
  * Alain Delorme
  * Guillaume Lelarge
  * Jean-Sébastien Bacq
  * Maël Rimbault
  * edechaux
  * Felix Geisendörfer
  * github user atorik
  * github user tbe
  * github user mikecaat
  * github user munakoiso
  * Christoph Berg
  * Sviatoslav Ermilin
  * Vitaliy Kukharik
  * Georgy Shelkovy
  * github user 1165125080
